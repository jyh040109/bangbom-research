"""대구시 미분양 원본 엑셀을 단지 목록과 구군별 총괄로 변환합니다."""
import argparse
import re
from pathlib import Path
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter


def convert(source, target):
    if source.resolve() == target.resolve():
        raise ValueError('원본과 다른 출력 파일명을 지정하세요.')
    book = load_workbook(source, data_only=True)
    detail, summary = book['업체별현황'], book['총괄표']
    rows = list(detail.values)
    date = re.search(r'(20\d{2})년\s*(\d{1,2})월', str(rows[0][0]))
    if not date or '소재지' not in str(rows[1][3]) or '당해월' not in str(rows[3][13]):
        raise ValueError('원본 표 구조가 예상과 다릅니다.')
    year, month = map(int, date.groups())
    from calendar import monthrange
    cutoff = f'{year}-{month:02d}-{monthrange(year, month)[1]:02d}'
    out = Workbook()
    info = out.active
    info.title = '출처와 안내'
    info.append(['항목', '내용'])
    for pair in [('기준일', cutoff), ('원본', source.name), ('출처', '대구광역시 주택과'), ('유의사항', '비공개 빈칸은 0이 아닙니다. 미분양 현황은 임대 공급 여부와 별개입니다.')]:
        info.append(pair)
    sheet = out.create_sheet('단지 목록')
    sheet.append(['구·군','읍·면·동','단지명','소재지·단지명 원문','준공 상태','입주예정(준공)월','총분양 가구수','전월 미분양','당월 미분양','수치 공개 여부','임대 공급 여부','원본 행','기준일'])
    districts = {summary.cell(i,1).value for i in range(5,14)}
    district = None
    starts = [i for i in range(4,len(rows)) if rows[i][3] or rows[i][1]]
    for i, end in zip(starts, starts[1:] + [len(rows)]):
        r = rows[i]
        if r[1]:
            label = str(r[1]).strip()
            match = re.search(r'\((.+?)지역\)', label)
            district = match[1] if match else label
        if not r[3]:
            continue
        if district not in districts:
            raise ValueError(f'{i+1}행: 구·군 확인 필요')
        raw = str(r[3]).strip()
        parts = raw.splitlines()
        name = ' '.join(parts[1:]).strip().strip('()') if len(parts)>1 and re.search(r'\d',parts[0]) else parts[0]
        details = [x for x in rows[i:end] if x[10] is not None]
        subtotal = [x for x in rows[i:end] if x[10] is None and isinstance(x[11],int)]
        total = sum(x[11] for x in details)
        if subtotal and subtotal[-1][11] != total:
            raise ValueError(f'{i+1}행: 총분양 소계 불일치')
        if '비공개' in str(r[12]) and r[13] is None:
            prev = curr = None
            status = '비공개'
        elif details and all(isinstance(x[k],int) for x in details for k in (12,13)):
            prev, curr = (sum(x[k] for x in details) for k in (12,13))
            if subtotal and tuple(subtotal[-1][12:14]) != (prev,curr):
                raise ValueError(f'{i+1}행: 미분양 소계 불일치')
            status = '공개'
        else:
            prev = curr = None
            status = '확인 필요'
        sheet.append([district,r[2],name,raw,' '.join(str(r[17] or '').split()),r[16],total,prev,curr,status,'확인 필요',i+1,cutoff])
    totals = out.create_sheet('구군별 총괄')
    totals.append(['지역','전월 미분양','당월 미분양','전월 대비','전월 준공 후 미분양','당월 준공 후 미분양','준공 후 전월 대비'])
    for i in range(4,14):
        if summary.cell(i,1).value != summary.cell(i+14,1).value:
            raise ValueError('총괄표 지역 배열이 다릅니다.')
        totals.append([summary.cell(i,1).value]+[summary.cell(j,k).value for j in (i,i+14) for k in (8,3,2)])
    for c in (2,3,4,5,6,7):
        if sum(totals.cell(i,c).value for i in range(3,12)) != totals.cell(2,c).value:
            raise ValueError('대구 총계와 구·군 합계가 다릅니다.')
    for tab,widths in [(info,[20,90]),(sheet,[13,17,42,57,29,21,17,17,17,19,19,14,16]),(totals,[15,18,18,17,24,24,22])]:
        tab.freeze_panes = 'A2'
        tab.auto_filter.ref = tab.dimensions
        for col,width in enumerate(widths,1):
            tab.column_dimensions[get_column_letter(col)].width=width
        for cell in tab[1]:
            cell.fill=PatternFill('solid',fgColor='204E44')
            cell.font=Font(color='FFFFFF',bold=True)
    out.save(target)
    print(f'완료: {sheet.max_row-1}개 단지 → {target}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('원본', type=Path)
    parser.add_argument('-o','--output', type=Path, default=Path('대구_미분양_단지목록.xlsx'))
    args = parser.parse_args()
    convert(args.원본,args.output)
